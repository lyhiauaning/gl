#!/bin/bash
echo '您现在可以使用的命令有：xml2ass'
sleep 0.16
echo 'xml2ass：将哔哩哔哩视频xml弹幕转换为ass格式'
sleep 0.16
echo '    参数:i:输入文件名'
echo '          o:输出文件名'
sleep 0.16
echo 'glo：原来的菜单'
sleep 0.16
echo 'vahb：视频&音频合并，视频不能有音频'
sleep 0.16
echo '    参数:a:输入音频'
echo '          v:输入视频'
echo '          o:输出视频'